<?php
require 'controllers/todoListController.php';
require "resources/database.php";


deleteList($id = $_GET['id']);


